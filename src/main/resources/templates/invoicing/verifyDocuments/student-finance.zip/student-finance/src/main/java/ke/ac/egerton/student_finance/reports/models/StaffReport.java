package ke.ac.egerton.student_finance.reports.models;

public class StaffReport {

    private String payrollId;
    private String fullName;

    public StaffReport() {
    }

    public String getPayrollId() {
        return payrollId;
    }

    public void setPayrollId(String payrollId) {
        this.payrollId = payrollId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

}
