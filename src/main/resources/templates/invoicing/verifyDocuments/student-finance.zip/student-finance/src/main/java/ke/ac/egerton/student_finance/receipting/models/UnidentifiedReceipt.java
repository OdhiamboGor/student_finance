package ke.ac.egerton.student_finance.receipting.models;

public class UnidentifiedReceipt {
}
