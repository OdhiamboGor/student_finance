package ke.ac.egerton.student_finance.studentInquiry.controllers.validation;

public class StudentInquiry {
}
