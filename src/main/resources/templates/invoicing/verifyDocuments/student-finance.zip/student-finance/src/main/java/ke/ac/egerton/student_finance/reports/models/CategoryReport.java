package ke.ac.egerton.student_finance.reports.models;

public class CategoryReport {

    private String code;
    private String name;

    public CategoryReport() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
