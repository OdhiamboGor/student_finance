package ke.ac.egerton.student_finance.studentInquiry.models;

public class StudentInquiry {
    private String studentField;

    public String getStudentField() {
        return studentField;
    }

    public void setStudentField(String studentField) {
        this.studentField = studentField;
    }
}
