package ke.ac.egerton.student_finance.quickDocuments.models;

public class StaffInquiry {

private String studentField;

    public String getStudentField() {
        return studentField;
    }

    public void setStudentField(String studentField) {
        this.studentField = studentField;
    }
}

